//Create modId parser dictionary 
/*

Input:  'modtypeid:moduniqueid'
        'form:123lkJDSo3msadfK'

Output: ''
*/
